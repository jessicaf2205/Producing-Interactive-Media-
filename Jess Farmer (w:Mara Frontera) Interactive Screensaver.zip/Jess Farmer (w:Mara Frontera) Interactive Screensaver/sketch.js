var radius1=30;
var radius2=35;
var radius3=40;
var radius4=45;

var x1 = 110;
var x2= 310;
var x3= 510;
var x4= 710;
var speed1;
var speed2;
var speed3;
var speed4;
var direction = 1;

function setup() {
    createCanvas(960, 593);
    ellipseMode(RADIUS);
}


function draw() {
background(0);
speed1 = 10;
speed2 = 8;
speed3 = 6;
speed4 = 4;
    

x1 += speed1 * direction;
x2 += speed2 * direction;
x3 += speed3 * direction;
x4 += speed4 * direction;
    

if ((x1 > width-radius1) || (x1 < radius1))
    
    {
    direction = -direction; 
}

if ((x2 >width-radius2) || (x2 <radius2))
    
{
    direction = -direction; 
}
    
if ((x3 >width-radius3)|| (x3 <radius3))
    
{
    direction = -direction;
}

    
if ((x4 > width-radius4)|| (x4 <radius4))
    
{
    direction = -direction; 

}



if (direction == 1) {
    
    arc(x1, 118, radius1, radius1, 0.52, 5.76); 
    
    arc(x2, 236, radius2, radius2, 0.52, 5.76);
        
    arc(x3, 354, radius3, radius3, 0.52, 5.76);
    
    arc(x4, 472, radius4, radius4, 0.52, 5.76);  
    
        fill(255,0,255);

    
} 
    
else {

    arc(x1, 98, radius4, radius4, 3.67, 8.9); 

    
    arc(x2, 196, radius3, radius3, 3.67, 8.9);

    arc(x3, 294, radius2, radius2, 3.67, 8.9);

        
    arc(x4, 392, radius1, radius1, 3.67, 8.9);
    
    fill (102,255,178);
    
    
    }
    
    if (mouseIsPressed){
        fill(255,0,0);
    }
    
    
}



